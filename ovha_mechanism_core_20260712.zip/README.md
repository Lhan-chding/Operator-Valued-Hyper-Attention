# OVHA Core Code

## Quick Start

Run the minimal training example after installing PyTorch:

```bash
python train_main.py --steps 20
```

Run the TANSO mechanism:

```bash
python train_main.py --steps 20 --candidates TANSOBase TANSOShift
```

Use `--help` to inspect preprocessing arguments:

```bash
python scripts/multimodal/build_cache.py --help
python scripts/multimodal/stage_cmu_sentiment_raw.py --help
python scripts/multimodal/stage_refcoco_raw.py --help
```

The basic training example requires `torch`. Data adapters and preprocessing steps may additionally require `numpy`, `h5py`, `mmdatasdk`, `Pillow`, and `transformers`.

## Root

- `train_main.py`: Config-free minimal training entry point. It creates an inline synthetic multimodal batch and runs the OVHA forward pass, masked MSE loss, backpropagation, and parameter update.
- `README.md`: Package structure and file guide.

## Data Contracts and Cache

- `moat_ovha_torch/__init__.py`: OVHA PyTorch package version entry point.
- `moat_ovha_torch/data/__init__.py`: Data package entry point.
- `moat_ovha_torch/data/multimodal/__init__.py`: Exports the multimodal batch structures.
- `moat_ovha_torch/data/multimodal/typed_batch.py`: Defines token fields, query fields, supervision, provenance, and model-input isolation rules.
- `moat_ovha_torch/data/multimodal/cache_schema.py`: Defines the multimodal cache layout, manifests, checksums, and integrity validation.

## CMU and RefCOCO Adapters

- `moat_ovha_torch/data/multimodal/adapters/__init__.py`: Exports the included CMU-MOSEI, CMU-MOSI, and RefCOCO adapters.
- `moat_ovha_torch/data/multimodal/adapters/base.py`: Common raw-data manifest, token-shard, supervision-shard, and adapter interfaces.
- `moat_ovha_torch/data/multimodal/adapters/cmu_mosei.py`: Converts CMU-MOSEI text, audio, vision, and label artifacts into the unified cache format.
- `moat_ovha_torch/data/multimodal/adapters/cmu_mosi.py`: Reuses the CMU-MOSEI pipeline for CMU-MOSI data.
- `moat_ovha_torch/data/multimodal/adapters/refcoco.py`: Converts RefCOCO expressions, region features, candidate boxes, and grounding labels into the unified cache format.

## OVHA Mechanism

- `moat_ovha_torch/models/__init__.py`: Model package entry point.
- `moat_ovha_torch/models/multimodal/__init__.py`: Defines the default multimodal operator candidates.
- `moat_ovha_torch/models/multimodal/ovha_multimodal.py`: Main OVHA model connecting evidence encoding, memory, routing, adaptation, candidate operators, and output composition.
- `moat_ovha_torch/models/multimodal/evidence.py`: Extracts global, local, and cross-modal evidence from modality fields and queries.
- `moat_ovha_torch/models/multimodal/memory.py`: Encodes evidence into operator-specific memory slots.
- `moat_ovha_torch/models/multimodal/router.py`: Computes candidate-operator weights from evidence, memory, and reliability signals.
- `moat_ovha_torch/models/multimodal/hyper_adapter.py`: Generates dynamic operator parameters from task context.
- `moat_ovha_torch/models/multimodal/joint_router_adapter.py`: Runs the router and hyper-adapter as a coupled module.
- `moat_ovha_torch/models/multimodal/reliability_prior.py`: Builds reliability priors from modality quality and availability.
- `moat_ovha_torch/models/multimodal/operator_bank.py`: Registers, creates, executes, and stacks candidate operators.
- `moat_ovha_torch/models/multimodal/baselines.py`: Defines same-feature baseline names and task-specific baseline requirements.

## Candidate Operators

- `moat_ovha_torch/models/multimodal/primitives/__init__.py`: Exports the main candidate-operator classes.
- `moat_ovha_torch/models/multimodal/primitives/base.py`: Common operator base class, output structure, and parameter-modulation utilities.
- `moat_ovha_torch/models/multimodal/primitives/typed_local_evidence.py`: TLEO, which aggregates typed local evidence with position and quality information.
- `moat_ovha_torch/models/multimodal/primitives/semantic_prototype.py`: SPO, which models global semantic structure with learnable prototypes.
- `moat_ovha_torch/models/multimodal/primitives/low_rank_interaction.py`: LRIO, which models low-rank interactions between modalities.
- `moat_ovha_torch/models/multimodal/primitives/alignment_transport.py`: CATO, which performs cross-modal token alignment through a transport mechanism.
- `moat_ovha_torch/models/multimodal/primitives/text_anchored_shift.py`: TANSO, which uses text as an anchor and applies gated shifts from other modalities.
- `moat_ovha_torch/models/multimodal/primitives/phrase_region_similarity.py`: PRSO, which scores phrase-to-region compatibility.
- `moat_ovha_torch/models/multimodal/primitives/spatial_relation_geometry.py`: SRO, which models candidate-box geometry and spatial relations.

## CMU-MOSEI and CMU-MOSI Preprocessing

- `scripts/__init__.py`: Script package entry point.
- `scripts/multimodal/__init__.py`: Multimodal script package entry point.
- `scripts/multimodal/inspect_cmu_sdk_sequences.py`: Inspects CMU SDK sequence names, shapes, and coverage.
- `scripts/multimodal/write_cmu_sdk_splits.py`: Writes train, validation, and test sample identifiers from the standard CMU SDK splits.
- `scripts/multimodal/extract_cmu_sdk_stage_inputs.py`: Extracts text, audio, vision, labels, and sample records from CMU SDK data.
- `scripts/multimodal/stage_cmu_sentiment_raw.py`: Validates and stages extracted CMU artifacts for cache construction.

## COCO and RefCOCO Preprocessing

- `scripts/multimodal/build_refcoco_expression_map.py`: Maps RefCOCO expressions, references, sentences, and images.
- `scripts/multimodal/build_refcoco_stage_records.py`: Builds expression, target-box, candidate-region, and split records.
- `scripts/multimodal/extract_refcoco_clip_features.py`: Extracts CLIP features for expressions and candidate image regions.
- `scripts/multimodal/align_refcoco_stage_features.py`: Aligns RefCOCO records and features by source identifier.
- `scripts/multimodal/stage_refcoco_raw.py`: Validates and stages RefCOCO features and supervision artifacts for cache construction.

## Cache Builder

- `scripts/multimodal/build_cache.py`: Builds and validates unified OVHA caches for CMU-MOSEI, CMU-MOSI, and RefCOCO.
