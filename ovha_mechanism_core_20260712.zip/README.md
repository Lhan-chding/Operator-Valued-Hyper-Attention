# OVHA Core Code Package

本压缩包只保留 OVHA 多模态机制核心、候选算子、一个无配置训练入口，以及 CMU-MOSEI/MOSI 与 COCO/RefCOCO 预处理代码。

## 快速运行

安装 PyTorch 后，可直接运行最小训练：

```bash
python train_main.py --steps 20
```

运行 TANSO 机制：

```bash
python train_main.py --steps 20 --candidates TANSOBase TANSOShift
```

预处理入口可用 `--help` 查看参数，例如：

```bash
python scripts/multimodal/build_cache.py --help
python scripts/multimodal/stage_cmu_sentiment_raw.py --help
python scripts/multimodal/stage_refcoco_raw.py --help
```

基础运行依赖 `torch` 和 `numpy`。CMU SDK、CLIP 特征提取等专项步骤还可能需要 `h5py`、`mmdatasdk`、`Pillow` 和 `transformers`。

## 根目录

- `train_main.py`：无 JSON 配置的最小训练入口；在线生成合成多模态 batch，执行 OVHA 前向、masked MSE、反向传播和参数更新。
- `README.md`：本文件，说明压缩包结构和各文件作用。

## 数据契约与缓存

- `moat_ovha_torch/__init__.py`：OVHA PyTorch 包版本入口。
- `moat_ovha_torch/data/__init__.py`：数据子包入口。
- `moat_ovha_torch/data/multimodal/__init__.py`：导出多模态 batch 数据结构。
- `moat_ovha_torch/data/multimodal/typed_batch.py`：定义 TokenField、QueryField、监督、来源信息及模型输入隔离规则。
- `moat_ovha_torch/data/multimodal/cache_schema.py`：定义多模态缓存目录、文件清单、校验和与完整性验证。

## CMU 与 RefCOCO 数据适配器

- `moat_ovha_torch/data/multimodal/adapters/__init__.py`：导出本包包含的 CMU-MOSEI、CMU-MOSI 和 RefCOCO 适配器。
- `moat_ovha_torch/data/multimodal/adapters/base.py`：原始数据 manifest、token shard、监督 shard 和适配器公共协议。
- `moat_ovha_torch/data/multimodal/adapters/cmu_mosei.py`：把 CMU-MOSEI 文本、音频、视觉特征和标签写成统一缓存。
- `moat_ovha_torch/data/multimodal/adapters/cmu_mosi.py`：复用 MOSEI 流程处理 CMU-MOSI 数据。
- `moat_ovha_torch/data/multimodal/adapters/refcoco.py`：把 RefCOCO 表达、区域特征、候选框和 grounding 标签写成统一缓存。

## OVHA 核心机制

- `moat_ovha_torch/models/__init__.py`：模型子包入口。
- `moat_ovha_torch/models/multimodal/__init__.py`：定义默认多模态候选算子名称。
- `moat_ovha_torch/models/multimodal/ovha_multimodal.py`：OVHA 主模型，串联证据编码、记忆、路由、适配、候选算子和预测组合。
- `moat_ovha_torch/models/multimodal/evidence.py`：从各模态和 query 中提取全局、局部及跨模态证据。
- `moat_ovha_torch/models/multimodal/memory.py`：把证据编码成每个候选算子对应的 operator memory slot。
- `moat_ovha_torch/models/multimodal/router.py`：根据证据、记忆和可靠性计算候选算子权重。
- `moat_ovha_torch/models/multimodal/hyper_adapter.py`：根据任务上下文动态生成各算子的适配参数。
- `moat_ovha_torch/models/multimodal/joint_router_adapter.py`：联合调用路由器和超适配器。
- `moat_ovha_torch/models/multimodal/reliability_prior.py`：根据模态质量和缺失状态生成可靠性先验。
- `moat_ovha_torch/models/multimodal/operator_bank.py`：注册、创建、执行并堆叠所有候选算子。
- `moat_ovha_torch/models/multimodal/baselines.py`：定义同特征基线名称和任务对应的基线要求。

## 候选算子

- `moat_ovha_torch/models/multimodal/primitives/__init__.py`：导出主要候选算子类。
- `moat_ovha_torch/models/multimodal/primitives/base.py`：候选算子公共基类、统一输出结构和参数调制工具。
- `moat_ovha_torch/models/multimodal/primitives/typed_local_evidence.py`：TLEO，聚合带类型、位置和质量信息的局部证据。
- `moat_ovha_torch/models/multimodal/primitives/semantic_prototype.py`：SPO，通过可学习语义原型建模全局语义结构。
- `moat_ovha_torch/models/multimodal/primitives/low_rank_interaction.py`：LRIO，建模不同模态之间的低秩交互。
- `moat_ovha_torch/models/multimodal/primitives/alignment_transport.py`：CATO，通过 transport 机制完成跨模态 token 对齐。
- `moat_ovha_torch/models/multimodal/primitives/text_anchored_shift.py`：TANSO，以文本为锚，利用其他模态执行有门控的表示位移。
- `moat_ovha_torch/models/multimodal/primitives/phrase_region_similarity.py`：PRSO，计算短语与候选图像区域的匹配关系。
- `moat_ovha_torch/models/multimodal/primitives/spatial_relation_geometry.py`：SRO，建模候选框位置、大小和空间关系。

## CMU-MOSEI/MOSI 预处理脚本

- `scripts/__init__.py`：脚本包入口。
- `scripts/multimodal/__init__.py`：多模态脚本包入口。
- `scripts/multimodal/inspect_cmu_sdk_sequences.py`：检查 CMU SDK 文件中的 sequence 名称、shape 和覆盖情况。
- `scripts/multimodal/write_cmu_sdk_splits.py`：根据 CMU SDK 标准划分写出 train、val、test 样本 ID。
- `scripts/multimodal/extract_cmu_sdk_stage_inputs.py`：从 CMU SDK 提取文本、音频、视觉序列、标签和样本记录。
- `scripts/multimodal/stage_cmu_sentiment_raw.py`：验证并登记抽取后的 CMU 原始特征，生成缓存构建所需 manifest。

## COCO/RefCOCO 预处理脚本

- `scripts/multimodal/build_refcoco_expression_map.py`：建立 RefCOCO expression、ref、sentence 与图像之间的映射。
- `scripts/multimodal/build_refcoco_stage_records.py`：生成表达、目标框、候选区域和 split 记录。
- `scripts/multimodal/extract_refcoco_clip_features.py`：提取表达文本和候选图像区域的 CLIP 特征。
- `scripts/multimodal/align_refcoco_stage_features.py`：按 source ID 对齐不同阶段产生的 RefCOCO 特征和记录。
- `scripts/multimodal/stage_refcoco_raw.py`：验证并登记 RefCOCO 原始特征与监督文件，生成缓存构建所需 manifest。

## 公共缓存构建入口

- `scripts/multimodal/build_cache.py`：只注册 CMU-MOSEI、CMU-MOSI 和 RefCOCO，将预处理产物转换为统一 OVHA 缓存并执行完整性检查。
