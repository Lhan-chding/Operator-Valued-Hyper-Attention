from __future__ import annotations

import argparse

import torch

from moat_ovha_torch.data.multimodal.typed_batch import (
    MultimodalEpisodeBatch,
    ProvenanceBank,
    QueryField,
    SupervisionBank,
    TokenField,
)
from moat_ovha_torch.models.multimodal.ovha_multimodal import MultimodalOVHA


def make_synthetic_batch(
    *,
    batch_size: int,
    token_count: int,
    query_count: int,
    field_dim: int,
    output_dim: int,
    device: torch.device,
) -> MultimodalEpisodeBatch:
    pass
    fields: dict[str, TokenField] = {}
    token_pos = torch.linspace(0.0, 1.0, token_count, device=device)
    token_pos = token_pos.view(1, token_count, 1).repeat(batch_size, 1, 2)
    for modality in ("text", "region", "audio"):
        fields[modality] = TokenField(
            modality=modality,
            x=torch.randn(batch_size, token_count, field_dim, device=device),
            pos=token_pos.clone(),
            mask=torch.ones(batch_size, token_count, dtype=torch.bool, device=device),
            quality=torch.ones(batch_size, token_count, 1, device=device),
        )

    query_x = torch.randn(batch_size, query_count, field_dim, device=device)
    query_pos = torch.linspace(0.0, 1.0, query_count, device=device)
    query_pos = query_pos.view(1, query_count, 1).repeat(batch_size, 1, 2)

    
    pooled = sum(field.x.mean(dim=1) for field in fields.values()) / len(fields)
    pooled = pooled[:, None, :].expand(-1, query_count, -1)
    target_y = torch.tanh(pooled[..., :output_dim] + query_x[..., :output_dim])

    return MultimodalEpisodeBatch(
        fields=fields,
        query=QueryField(
            x=query_x,
            pos=query_pos,
            query_type=torch.zeros(batch_size, query_count, dtype=torch.long, device=device),
            mask=torch.ones(batch_size, query_count, dtype=torch.bool, device=device),
        ),
        target_y=target_y,
        target_mask=torch.ones(batch_size, query_count, dtype=torch.bool, device=device),
        task_type="synthetic_multimodal",
        split="train",
        source_dataset="inline_synthetic",
        supervision=SupervisionBank(
            task_label=None,
            alignment_pairs=None,
            alignment_weights=None,
            bbox_targets=None,
            region_targets=None,
            timestamp_targets=None,
            modality_missing_mask=None,
            corruption_metadata=None,
            weak_labels=None,
            weak_label_confidence=None,
            pseudo_label_source=None,
        ),
        provenance=ProvenanceBank(
            source_id=[f"synthetic-{index}" for index in range(batch_size)],
            original_split=["train"] * batch_size,
            raw_ref=["generated-inline"] * batch_size,
            license_tag=["synthetic"] * batch_size,
            preprocessing_version="inline-v1",
            feature_extractor_version={"text": "inline", "region": "inline", "audio": "inline"},
            pseudo_label_version={},
        ),
    )


def train(args: argparse.Namespace) -> None:
    if args.output_dim > args.field_dim:
        raise ValueError("--output-dim must not exceed --field-dim in this minimal synthetic runner")
    for name in ("steps", "batch_size", "token_count", "query_count", "field_dim", "output_dim", "d_model", "memory_tokens", "log_interval"):
        if getattr(args, name) <= 0:
            raise ValueError(f"--{name.replace('_', '-')} must be positive")
    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    model = MultimodalOVHA(
        field_dims={"text": args.field_dim, "region": args.field_dim, "audio": args.field_dim},
        query_dim=args.field_dim,
        output_dim=args.output_dim,
        d_model=args.d_model,
        memory_tokens=args.memory_tokens,
        candidate_names=tuple(args.candidates),
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate)

    model.train()
    for step in range(1, args.steps + 1):
        batch = make_synthetic_batch(
            batch_size=args.batch_size,
            token_count=args.token_count,
            query_count=args.query_count,
            field_dim=args.field_dim,
            output_dim=args.output_dim,
            device=device,
        )
        optimizer.zero_grad(set_to_none=True)
        output = model(batch)
        squared_error = (output.y_hat - batch.target_y).square()
        mask = batch.target_mask.unsqueeze(-1).to(squared_error.dtype)
        denominator = (mask.sum() * squared_error.shape[-1]).clamp_min(1.0)
        loss = (squared_error * mask).sum() / denominator
        loss.backward()
        optimizer.step()

        if step == 1 or step == args.steps or step % args.log_interval == 0:
            loads = output.router_weights.detach().mean(dim=(0, 1)).cpu().tolist()
            load_text = ", ".join(
                f"{name}={value:.3f}" for name, value in zip(model.candidate_names, loads)
            )
            print(f"step={step:04d} loss={loss.item():.6f} router_load=[{load_text}]")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--steps", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--token-count", type=int, default=8)
    parser.add_argument("--query-count", type=int, default=4)
    parser.add_argument("--field-dim", type=int, default=8)
    parser.add_argument("--output-dim", type=int, default=2)
    parser.add_argument("--d-model", type=int, default=32)
    parser.add_argument("--memory-tokens", type=int, default=4)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--device", default="cpu")
    parser.add_argument(
        "--candidates",
        nargs="+",
        default=["TLEO", "SPO", "LRIO", "CATO"],
        help="Operator candidates, e.g. TLEO SPO LRIO CATO or TANSOBase TANSOShift.",
    )
    parser.add_argument("--log-interval", type=int, default=5)
    return parser.parse_args()


if __name__ == "__main__":
    train(parse_args())
