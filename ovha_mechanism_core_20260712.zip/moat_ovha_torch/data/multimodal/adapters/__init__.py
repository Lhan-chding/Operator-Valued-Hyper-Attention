pass

from moat_ovha_torch.data.multimodal.adapters.cmu_mosei import CMUMOSEIAdapter
from moat_ovha_torch.data.multimodal.adapters.cmu_mosi import CMUMOSIAdapter
from moat_ovha_torch.data.multimodal.adapters.refcoco import RefCOCOAdapter

__all__ = ["CMUMOSEIAdapter", "CMUMOSIAdapter", "RefCOCOAdapter"]
