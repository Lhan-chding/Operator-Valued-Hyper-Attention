from __future__ import annotations

import torch
from torch import nn

from moat_ovha_torch.models.multimodal.primitives.base import CandidateOutput, MultimodalCandidatePrimitive, apply_scale_bias
from moat_ovha_torch.models.multimodal.primitives.phrase_region_similarity import _fit_output_dim, _masked_mean
from moat_ovha_torch.models.multimodal.primitives.spatial_relation_geometry import _region_geometry


# TLEO: typed local aggregation with geometry and quality-aware source weighting.
class TLEOPrimitive(MultimodalCandidatePrimitive):
    name = "TLEO"

    def __init__(self, d_model: int, output_dim: int, modalities: tuple[str, ...] = ("text", "audio", "vision", "region")):
        super().__init__()
        self.modalities = modalities
        self.query_proj = nn.ModuleDict({name: nn.Linear(d_model, d_model) for name in modalities})
        self.key_proj = nn.ModuleDict({name: nn.Linear(d_model, d_model) for name in modalities})
        self.value_proj = nn.ModuleDict({name: nn.Linear(d_model, d_model) for name in modalities})
        self.source_gate = nn.ModuleDict({name: nn.Linear(d_model + 1, 1) for name in modalities})
        self.shared_query_proj = nn.Linear(d_model, d_model)
        self.shared_key_proj = nn.Linear(d_model, d_model)
        self.shared_value_proj = nn.Linear(d_model, d_model)
        self.shared_source_gate = nn.Linear(d_model + 1, 1)
        self.memory_gate = nn.Linear(d_model * 2, d_model)
        self.text_region_query = nn.Linear(d_model, d_model)
        self.text_region_key = nn.Linear(d_model, d_model)
        self.region_query = nn.Linear(d_model, d_model)
        self.region_key = nn.Linear(d_model, d_model)
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, output_dim)

    def forward(self, batch, memory_slot: torch.Tensor, evidence, params: dict[str, torch.Tensor], output_dim: int) -> CandidateOutput:
        if "text" in evidence.field_features and "region" in evidence.field_features and output_dim == int(evidence.field_features["region"].shape[1]):
            return self._forward_region_local_context(batch, memory_slot, evidence, params, output_dim)
        local_values = []
        local_entropies = []
        source_gate_logits = []
        source_valid = []
        source_names = []
        lengthscale = params["lengthscale"].clamp_min(1e-4)
        temperature = params["local_temperature"].clamp_min(1e-4)
        for name, projected_tokens in evidence.field_features.items():
            field = batch.fields[name]
            q_proj, k_proj, v_proj, gate_proj = self._modules_for(name)
            query = q_proj(evidence.query_features)
            keys = k_proj(projected_tokens)
            logits = _local_kernel_logits(
                query,
                keys,
                batch.query.pos,
                field.pos,
                lengthscale,
                temperature,
            )
            valid_source = field.mask.to(device=logits.device).any(dim=1)
            token_mask = field.mask.to(device=logits.device).unsqueeze(1)
            logits = logits.masked_fill(~token_mask, -1e9)
            weights = torch.softmax(logits, dim=-1)
            weights = torch.where(valid_source.view(-1, 1, 1), weights, torch.zeros_like(weights))
            value = torch.matmul(weights, v_proj(projected_tokens))
            value = torch.where(valid_source.view(-1, 1, 1), value, torch.zeros_like(value))
            quality = _field_quality(field, dtype=value.dtype, device=value.device)
            gate_input = torch.cat([value.mean(dim=1), quality], dim=-1)
            source_gate_logits.append(gate_proj(gate_input).unsqueeze(1))
            local_values.append(value)
            local_entropies.append(-(weights * weights.clamp_min(1e-12).log()).sum(dim=-1).mean())
            source_valid.append(valid_source)
            source_names.append(name)
        if local_values:
            local_stack = torch.stack(local_values, dim=-2)
            valid_stack = torch.stack(source_valid, dim=-1)
            gate_logits = torch.cat(source_gate_logits, dim=-1).masked_fill(~valid_stack.unsqueeze(1), -1e9)
            source_gates = torch.softmax(gate_logits, dim=-1)
            source_gates = source_gates * valid_stack.unsqueeze(1).to(dtype=source_gates.dtype)
            source_gates = source_gates / source_gates.sum(dim=-1, keepdim=True).clamp_min(1.0)
            source_gates = source_gates.unsqueeze(-1)
            local_feature = (source_gates * local_stack).sum(dim=-2)
        else:
            source_gates = torch.zeros(1, device=evidence.query_features.device)
            local_feature = evidence.local_features
        memory = memory_slot.mean(dim=1).unsqueeze(1).expand_as(local_feature)
        feature = self.norm(local_feature + self.memory_gate(torch.cat([local_feature, memory], dim=-1)))
        value = apply_scale_bias(self.head(feature), params)
        diagnostics = {
            "lengthscale": params.get("lengthscale"),
            "local_temperature": params.get("local_temperature"),
            "local_entropy": torch.stack(local_entropies).mean() if local_entropies else evidence.local_entropy,
            "local_window_size": torch.as_tensor(feature.shape[1], device=value.device),
            "modality_kernel_count": torch.as_tensor(float(len(source_names)), dtype=value.dtype, device=value.device),
            "modality_kernel_names": tuple(source_names),
            "modality_gate": {
                name: source_gates[..., index, 0].mean()
                for index, name in enumerate(source_names)
            } if local_values else {},
            "valid_source_rate": {
                name: source_valid[index].to(dtype=value.dtype).mean()
                for index, name in enumerate(source_names)
            } if local_values else {},
            "candidate": self.name,
        }
        return CandidateOutput(value=value, feature=feature, diagnostics=diagnostics)

    def _modules_for(self, name: str):
        if name in self.query_proj:
            return self.query_proj[name], self.key_proj[name], self.value_proj[name], self.source_gate[name]
        return self.shared_query_proj, self.shared_key_proj, self.shared_value_proj, self.shared_source_gate

    def _forward_region_local_context(self, batch, memory_slot: torch.Tensor, evidence, params: dict[str, torch.Tensor], output_dim: int) -> CandidateOutput:
        text = evidence.field_features["text"]
        region = evidence.field_features["region"]
        region_field = batch.fields["region"]
        region_mask = region_field.mask.to(device=region.device)
        phrase = _masked_mean(text, batch.fields["text"].mask)
        base_query = self.text_region_query(phrase)
        base_key = self.text_region_key(region)
        base = (base_query.unsqueeze(1) * base_key).sum(dim=-1) / max(region.shape[-1] ** 0.5, 1.0)

        geometry = _region_geometry(region_field.pos, dtype=region.dtype, device=region.device)
        geo_dist = _pairwise_geometry_distance(geometry)
        pair_iou = _pairwise_box_iou(geometry)
        semantic = torch.matmul(self.region_query(region), self.region_key(region).transpose(1, 2)) / max(region.shape[-1] ** 0.5, 1.0)
        lengthscale = params["lengthscale"].mean(dim=1).clamp_min(1e-4).unsqueeze(-1)
        temperature = params["local_temperature"].mean(dim=1).clamp_min(1e-4).unsqueeze(-1)
        kernel = -geo_dist / lengthscale.square().clamp_min(1e-6) + 0.5 * pair_iou + semantic / temperature
        pair_mask = region_mask.unsqueeze(1) & region_mask.unsqueeze(2)
        kernel = kernel.masked_fill(~pair_mask, -1e9)
        weights = torch.softmax(kernel, dim=-1)
        weights = torch.where(region_mask.unsqueeze(-1), weights, torch.zeros_like(weights))
        local = torch.matmul(weights, base.unsqueeze(-1)).squeeze(-1)
        logits = (base + params.get("transport_scale", torch.ones_like(base.unsqueeze(1))).mean(dim=1) * local).unsqueeze(1)
        logits = logits.masked_fill(~region_mask.unsqueeze(1), -1e9)
        value = apply_scale_bias(_fit_output_dim(logits, output_dim), params)
        summary_weights = torch.softmax(logits, dim=-1)
        memory = memory_slot.mean(dim=1).unsqueeze(1)
        feature = self.norm(torch.matmul(summary_weights, region) + self.memory_gate(torch.cat([torch.matmul(summary_weights, region), memory], dim=-1)))
        diagnostics = {
            "lengthscale": params.get("lengthscale"),
            "local_temperature": params.get("local_temperature"),
            "local_entropy": -(weights * weights.clamp_min(1e-12).log()).sum(dim=-1)[region_mask].mean(),
            "local_window_size": torch.as_tensor(float(region.shape[1]), dtype=value.dtype, device=value.device),
            "modality_kernel_count": torch.as_tensor(1.0, dtype=value.dtype, device=value.device),
            "modality_kernel_names": ("region",),
            "modality_gate": {"region": torch.ones((), dtype=value.dtype, device=value.device)},
            "valid_source_rate": {"region": region_mask.any(dim=1).to(dtype=value.dtype).mean()},
            "region_local_context": True,
            "region_graph_kernel": "center_size_distance_plus_iou_plus_visual_similarity",
            "mean_pairwise_iou": pair_iou[pair_mask].mean() if bool(pair_mask.any()) else torch.zeros((), dtype=value.dtype, device=value.device),
            "direct_region_logits": True,
            "candidate": self.name,
        }
        return CandidateOutput(value=value, feature=feature, diagnostics=diagnostics)


def _local_kernel_logits(
    query: torch.Tensor,
    tokens: torch.Tensor,
    query_pos: torch.Tensor,
    token_pos: torch.Tensor,
    lengthscale: torch.Tensor,
    temperature: torch.Tensor,
) -> torch.Tensor:
    semantic = torch.matmul(query, tokens.transpose(1, 2)) / max(query.shape[-1] ** 0.5, 1.0)
    pos_dims = min(int(query_pos.shape[-1]), int(token_pos.shape[-1]))
    if pos_dims <= 0:
        distance_term = torch.zeros_like(semantic)
    else:
        q_pos = query_pos[..., :pos_dims].to(dtype=query.dtype, device=query.device)
        t_pos = token_pos[..., :pos_dims].to(dtype=query.dtype, device=query.device)
        distance_term = (q_pos.unsqueeze(2) - t_pos.unsqueeze(1)).square().sum(dim=-1)
    return -distance_term / lengthscale.square().clamp_min(1e-6) + semantic / temperature


def _field_quality(field, *, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    if field.quality is None:
        return field.mask.to(device=device).any(dim=1, keepdim=True).to(dtype=dtype)
    return field.quality.to(dtype=dtype, device=device).reshape(field.quality.shape[0], -1).mean(dim=1, keepdim=True)


def _pairwise_geometry_distance(geometry: torch.Tensor) -> torch.Tensor:
    centers = geometry[..., 4:6]
    sizes = geometry[..., 6:8]
    center_distance = (centers.unsqueeze(2) - centers.unsqueeze(1)).square().sum(dim=-1)
    size_distance = (sizes.unsqueeze(2) - sizes.unsqueeze(1)).square().sum(dim=-1)
    return center_distance + 0.25 * size_distance


def _pairwise_box_iou(geometry: torch.Tensor) -> torch.Tensor:
    x1 = torch.maximum(geometry[..., 0].unsqueeze(2), geometry[..., 0].unsqueeze(1))
    y1 = torch.maximum(geometry[..., 1].unsqueeze(2), geometry[..., 1].unsqueeze(1))
    x2 = torch.minimum(geometry[..., 2].unsqueeze(2), geometry[..., 2].unsqueeze(1))
    y2 = torch.minimum(geometry[..., 3].unsqueeze(2), geometry[..., 3].unsqueeze(1))
    inter = (x2 - x1).clamp_min(0.0) * (y2 - y1).clamp_min(0.0)
    area = geometry[..., 8].clamp_min(0.0)
    union = area.unsqueeze(2) + area.unsqueeze(1) - inter
    return inter / union.clamp_min(1e-8)
